import React, { Component } from 'react';

class ModalForgetPassword extends Component {
    state = {  }
    render() { 
        return (  
            <h1>ModalForgetPassword</h1>
        );
    }
}
 
export default ModalForgetPassword;