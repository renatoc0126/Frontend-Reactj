import React, { Component } from 'react'
import TopHeader from '../../components/common/Header/TopHeader';
import JoinForm from '../../components/homePage/JoinForm';
import Footer from '../../components/common/Footer';
import StartInvestingContent from '../../components/startInvestingPage/StartInvestingContent';

export class index extends Component {
    render() {
        return (
            <div>
                <TopHeader />

                <StartInvestingContent />
                
                <JoinForm />

                <Footer />
            </div>
        )
    }
}

export default index
