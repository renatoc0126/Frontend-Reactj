import React, { Component } from 'react'
import '../../../css/dashboard/support.css'

export class index extends Component {
    componentDidMount(){
        this.props.selectLeftSidebar('supportState');
    }
    render() {
        return (
            <div className="support-container animation-effect">
                <p className="dashboard-sub-title dark-blue">Contact Support</p>
                <div className="contact-form-main">
                    <div className="form-group dashboard-form-group">
                        <input type="text" className="form-control" placeholder="Subject"></input>
                    </div>
                    <div className="contact-support-textarea-container">
                        <textarea className="contact-support-textarea"></textarea>
                    </div>
                    <button>Submit</button>
                </div>
            </div>
        )
    }
}

export default index
