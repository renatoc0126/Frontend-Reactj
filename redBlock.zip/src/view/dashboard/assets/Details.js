import React, { Component } from 'react'
// import { Link } from 'react-router-dom'

import DescriptionIcon from '@material-ui/icons/Description';
// import CheckIcon from '@material-ui/icons/Check';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';

// import Checkbox from '@material-ui/core/Checkbox';
// import IconButton from '@material-ui/core/IconButton';
import transactionTableData from '../../../data/transactionTableData.json'
import '../../../css/dashboard/details.css'


class Details extends Component {
    state = {  
        table_data: []
    }
    componentDidMount= () => {
        this.setState({table_data: transactionTableData});
    }
    handleTrnasactions = transaction => {
        if(transaction==="Approved"){
            // return <CheckIcon/>;
            return <img src={"../../assets/icons/check-square.png"} alt="check square icon" style={{width:"18px"}}/>;
        }
        else if(transaction==="Decline"){
            return <ErrorOutlineIcon/>;
        }
        else{
            return <HighlightOffIcon />;
        }
    }
    handleClass = transaction => {
        if(transaction==="Approved"){
            return "check-approved";
            
        }
        else if(transaction==="Decline"){
            return "decline";
        }
        else{
            return "revoke";
        }
    }
    render() { 
        // console.log(this.state.table_data);
        return (  
            <div className="details">
                <div className="transaction">Transaction</div>
                <div className="transaction-table-contain">
                    <table className="table transaction-table">
                        <thead>
                            <tr>
                                <th>Offering Name</th>
                                <th>Investor</th>
                                <th>Amount</th>
                                <th>Price per unit</th>
                                <th>Created date</th>
                                <th>Time</th>
                                <th>Document</th>
                                <th>Transactions</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        {this.state.table_data.map((data, i) => 
                            <tr key={i}>
                                <td>{data.offering_name}</td>
                                <td>{data.investor}</td>
                                <td>{data.amount}</td>
                                <td>{data.price_per_unit}</td>
                                <td>{data.created_date}</td>
                                <td>{data.time}</td>
                                <td><DescriptionIcon/></td>
                                <td>
                                    <span className={this.handleClass(data.transactions)}>
                                        {this.handleTrnasactions(data.transactions)}
                                        <span className="pl-2">{data.transactions}</span>
                                    </span>
                                    
                                </td>
                                <td>{data.status}</td>
                            </tr>
                            )}
                           
                        </tbody>
                    </table>
                </div>
            </div>
            
        );
    }
}
 
export default Details;
