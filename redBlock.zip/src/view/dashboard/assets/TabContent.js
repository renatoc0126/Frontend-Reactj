import React, { Component } from 'react'
import TabList from './TabList'
import CommentsData from '../../../data/commentsData.json'

export class TabContent extends Component {
    constructor(props){
        super(props);
        this.state = {
            commentData: [],
            showCommentData: [],
            viewAllState: false,
        }
    }

    componentDidMount(){
        this.setState({commentData: CommentsData});
        var temp = [];
        if(CommentsData.length>4)
            temp = CommentsData.slice(0, 4);
        else
            temp = CommentsData.slice(0, CommentsData.length);
        this.setState({showCommentData: temp});
    }

    toggleViewAll = () => {
        var element, name, i;
        this.setState({viewAllState: !this.state.viewAllState},() => {
            if(this.state.viewAllState){
                 this.setState({showCommentData: this.state.commentData}, ()=>{
                    for(i=4; i<this.state.commentData.length; i++){
                        element = document.getElementById("key" + i);
                        name="fade-down";
                        element.className += " " + name;
                    }
                 });
            }
            else {
                    for(i=4; i<this.state.commentData.length; i++){
                        element = document.getElementById("key" + i);
                        element.classList.remove("fade-in");
                        name = "fade-up";
                        element.className += " " + name;
                    }
                    setTimeout(() => {
                        this.setState({showCommentData: this.state.commentData.slice(0, 4)});
                    }, 800);
            }
        }
        );
    }


    render() {
        return (
            <div>
                <TabList>
                    <div label="FAQ" className="dashboard-tab-content">
                        {this.state.showCommentData.map((object, i)=>
                            <div key={i} className="avatar-comment-item">
                                <div className="comment-description-created">
                                    <p className="comment-description">{object.description}</p>
                                    <p className="comment-created">{object.created} hours ago</p>
                                </div>
                            </div>
                        )}
                    </div>
                    <div label="Updates(4)" className="dashboard-tab-content">
                    {this.state.showCommentData.map((object, i)=>
                            <div key={i} className="avatar-comment-item">
                                <div className="comment-description-created">
                                    <p className="comment-description">{object.description}</p>
                                    <p className="comment-created">{object.created} hours ago</p>
                                </div>
                            </div>
                        )}
                    </div>
                    <div label={"Comments (" + CommentsData.length + ")"} className="dashboard-tab-content">
                        {
                            this.state.showCommentData.map((object, i)=>
                                <div key={i} className="avatar-comment-item" id={"key"+i}>
                                    <div className="avatar-name-address-contain">
                                        <div className="flex-vertical-align comment-avatar-contain">
                                            <img src={object.url} alt={i + 1} className="dashboard-img-avator"></img>
                                        </div>
                                        <div className="comment-name-address">
                                            <p className="comment-name">{object.name}</p>
                                            <p className="comment-address">{object.address}</p>
                                        </div>
                                    </div>
                                    <div className="comment-description-created">
                                        <p className="comment-description">{object.description}</p>
                                        <p className="comment-created">{object.created} hours ago</p>
                                    </div>
                                </div>
                            )
                        }
                        <div className="avatar-comment-item view-all-btn-contain">
                            <button onClick={()=>this.toggleViewAll()}>
                                {this.state.viewAllState ? "Less": "View all"}
                            </button>
                        </div>
                    </div>
                </TabList>
            </div>
        )
    }
}

export default TabContent
