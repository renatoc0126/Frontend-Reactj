import React, { Component } from 'react';
import TabList from './AccountList';

import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';

import '../../../css/dashboard/account.css'
import Select from "react-select";
const country = [
    { value: "China", label: "China" },
    { value: "UniteState", label: "UniteState" },
    { value: "Serbia", label: "serbia" },
];
export default class Account extends Component {

    constructor(props){
        super(props);
        this.state = {
            emailConfirmState: false,
        }
    }

    componentDidMount(){
        this.props.selectLeftSidebar('accountState');
    }

    handleOpen = () => {
        this.setState({emailConfirmState: true});
    };
    
    handleClose = () => {
        this.setState({emailConfirmState: false});
    };

    render() {
        return (
            <div className="up  animation-effect da-account-container">
                <TabList>
{/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ acccout setting section@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */}
                    <div label="Settings" className="tab-content">
                        <div className="col-12 setting-content">
                            <div className="col-xl-8 account-settings"> 
                                <div className="row account-contents">
                                <div className="col-lg-6 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>First Name</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                                                  
                                    </div>
                                    <div className="col-lg-6 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Last Name</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                       
                                    </div>
                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Company Name</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                       
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Company Email Address</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Phone Number</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>
                                    <div className="col-lg-12 col-md-12 form-group-row d-flex justify-content-center">
                                        <button type="button" className="account-setting-save-btn form-group round-btn">Save</button>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
{/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Company profile section@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */}
                    <div label="Company Profile" className="tab-content">                        
                        <div className="profile-content"> 
                            <div className="col-xl-7">  
{/*----------------------Documention start---------------------*/}
                                <div className="row document-row">
                                    <div className="form-group-row">
                                        <h4>Docmentation</h4>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Incorporation Documents</label>
                                        <div className="input-group">                                        
                                            <div className="input-group-prepend ">
                                                <span className="input-group-text paper-pre"><i className="fa fa-paperclip paper-icon" aria-hidden="true"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control prepend-input" name="#" placeholder="Pdf file upto 10MB"/>
                                        </div>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Copporate Bylaws</label>
                                        <div className="input-group mb-3">                                        
                                            <div className="input-group-prepend ">
                                                <span className="input-group-text paper-pre" ><i className="fa fa-paperclip paper-icon" aria-hidden="true"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control prepend-input" name="#" placeholder="Pdf file upto 10MB"/>
                                        </div>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Organizational Chart</label>
                                        <div className="input-group mb-3">                                        
                                            <div className="input-group-prepend ">
                                                <span className="input-group-text paper-pre"><i className="fa fa-paperclip paper-icon" aria-hidden="true"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control prepend-input" name="#" placeholder="Pdf file upto 10MB"/>
                                        </div>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Cap-table</label>
                                        <div className="input-group mb-3">                                        
                                            <div className="input-group-prepend ">
                                                <span className="input-group-text paper-pre"><i className="fa fa-paperclip paper-icon" aria-hidden="true"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control prepend-input" name="#" placeholder="Pdf file upto 10MB"/>
                                        </div>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Company Description</label>
                                        <div className="input-group mb-3">                                        
                                            <div className="input-group-prepend ">
                                                <span className="input-group-text paper-pre"><i className="fa fa-paperclip paper-icon" aria-hidden="true"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control prepend-input" name="#" placeholder="Pdf file upto 10MB"/>
                                        </div>
                                    </div>
                                </div>
{/*-------------------------Address start----------------------------*/}
                                <div className="row address-row">
                                    <div className="form-group-row">
                                        <h4>Address</h4>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Street Address</label>
                                        <div className="input-group">                                        
                                            <div className="input-group-prepend ">
                                                <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                            </div>                               
                                            <input type="text" className="form-control prepend-input" name="#" />
                                        </div>
                                    </div>

                                    <div className="form-group profile-row">
                                        <label>Apartment, suite or unit number</label>
                                        <input type="text" className="form-control prepend-input unit-number" />
                                    </div>

                                    <div className="row form-group profile-row address-items">
                                        <div className="col-md-6 address-item1">
                                            <label>City</label>
                                            <div className="input-group">                                        
                                                <div className="input-group-prepend ">
                                                    <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                </div>                               
                                                <input type="text" className="form-control prepend-input" name="#" />
                                            </div>
                                        </div>
                                        <div className="col-md-6 address-item2">
                                            <label>Zipcode</label>
                                            <div className="input-group">                                        
                                                <div className="input-group-prepend ">
                                                    <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                </div>                               
                                                <input type="text" className="form-control prepend-input" name="#" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row form-group profile-row address-items">
                                        <div className="col-md-6 address-item1">
                                            <label>State</label>
                                            <div className="input-group">                                        
                                                <div className="input-group-prepend ">
                                                    <span className="input-group-text location-pre"><i className="fa fa-map-marker"></i></span>
                                                </div>                               
                                                <input type="text" className="form-control prepend-input" name="#" />
                                            </div>
                                        </div>
                                        <div className="col-md-6 address-item2">
                                            <div className="form-group select-wrapper redbackground-select-wrapper">
                                                <label>Country</label>
                                                <Select options={country}/>
                                            </div> 
                                        </div>
                                    </div>

                                    <div className="profile-row d-flex justify-content-center" style={{width: "100%"}}>
                                        <button type="button" className="company-profile-sub-btn round-btn" onClick={()=>this.handleOpen()}>Submit for Approval</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
{/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Change password section@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ */}                                        
                    <div label="Change Password" className="tab-content">
                        <div className="col-12 setting-content">
                            <div className="col-lg-5 chnagePassword-settings"> 
                                <div className="row account-contents">
                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Current Password</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>                                                       
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>New Password</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>

                                    <div className="col-lg-12 col-md-12 form-group-row">
                                        <div className="form-group">
                                            <label>Re-enter New Password</label>
                                            <input type="text" className="form-control account-setting-input"  required="" />
                                        </div>  
                                    </div>
                                    <div className="col-lg-12 col-md-12 form-group-row d-flex justify-content-center">
                                        <button type="button" className="account-setting-save-btn form-group round-btn">Save</button>
                                    </div>
                                </div>     
                            </div>
                        </div>
                    </div>
                </TabList>

                <Modal
                    aria-labelledby="transition-modal-title"
                    aria-describedby="transition-modal-description"
                    className="email-confirm-modal"
                    open={this.state.emailConfirmState}
                    onClose={()=>this.handleClose()}
                    closeAfterTransition
                    BackdropComponent={Backdrop}
                    BackdropProps={{
                    timeout: 500,
                    }}
                >
                    <Fade in={this.state.emailConfirmState}>
                    <div className="email-confrim-main application-sub">
                        <div className="email-box-main">
                            <img src="../../images/tick.png" alt="tick png"/>
                        </div>
                        <div>
                            <h3 className="dark-blue"><strong>Your Application has been submitted</strong></h3>
                            <p>
                                You'll received a notification once your application is approved
                            </p>
                        </div><br></br><br></br><br></br>
                        <div>
                            <button className="round-lightred-btn-sm account-modal-btn" onClick={() => this.handleClose()}>Back</button>
                        </div>
                    </div>
                    </Fade>
                </Modal>
            </div>
        );
    }
}