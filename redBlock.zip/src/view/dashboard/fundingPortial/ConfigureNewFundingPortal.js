import React, { Component } from 'react'
import IconButton from '@material-ui/core/IconButton';
import Select from "react-select";
const options1 = [
    { value: "China", label: "China" },
    { value: "UniteState", label: "UniteState" },
    { value: "Serbia", label: "serbia" },
  ];

export class ConfigureNewFundingPortal extends Component {
    componentDidMount(){
        this.props.selectLeftSidebar('fundingState');
    }
    
    render() {
        return (
            <div className="confiure-new-funding-portal-container animation-effect">
                <p className="dashboard-sub-title dark-blue">Confiure New Funding Portal</p>

                <div className="asset-info-container">
                    <div className="asset-input-group">
                        <p className="asset-title">Asset info</p>
                        <div className="form-group dashboard-form-group">
                            <label>Asset Name</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Target Raise</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Price Per Unit</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Minimun Investment</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group">
                            <label>Asset Website</label>
                            <input type="text" className="form-control"></input>
                        </div>
                        <div className="form-group dashboard-form-group funding-country-select-wrapper">
                            <label>Country</label>
                            <Select options={options1} />
                        </div>
                        
                    </div>
                    <div className="asset-input-upload-edit">
                        <div className="upload-edit-contain">
                            <div className="http-inputbox-container">
                                <input type="text" placeholder="http://" />
                                <p>Upload YouTube Channel Link</p>
                            </div>
                            <div>
                                <IconButton component="label" className="upload-icon-btn">
                                    <i className="fa fa-cloud-upload"></i>
                                    <input
                                        type="file"
                                        name="media"
                                        accept="audio/*,video/*,image/*"
                                        style={{ display: "none" }}
                                    />
                                </IconButton>

                                <p>Upload Media</p>
                            </div>
                            <div>
                                
                                <button>
                                    <i className="fa fa-pencil-square-o"></i>
                                    Edit
                                </button>
                                <p>Drag your media files here or browse</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="funding-high-ligt">
                    <p className="asset-title">Highlight</p>
                    <p className="small-sub-title">Why Invest Us?</p>
                    <div className="text-edit-contain">
                        <textarea className="textarea-edit-body"></textarea>
                    </div>
                </div>

                <div className="funding-high-ligt">
                    <p className="asset-title">Overview</p>
                    <div className="text-edit-contain">
                        <textarea className="textarea-edit-body"></textarea>
                    </div>
                </div>

                <div className="funding-high-ligt">
                    <p className="asset-title">Description</p>
                    <div className="text-edit-contain">
                        <textarea className="textarea-edit-body"></textarea>
                    </div>
                </div>

                <div className="funding-high-ligt pitch-dech-upload-main">
                    <p className="asset-title">Pitch Deck (PDF)</p>
                    <div className="pitch-dech-upload-contain">
                        <IconButton component="label" className="upload-icon-btn">
                            <i className="fa fa-cloud-upload"></i>
                            <input
                                type="file"
                                name="pdf"
                                accept=".doc, .docx,.ppt, .pptx,.txt,.pdf"
                                style={{ display: "none" }}
                            />
                        </IconButton>
                        <p>Upload PDF file</p>
                    </div>
                </div>

                <div className="funding-high-ligt">
                    <p className="asset-title">Risk Factors & Disclosure</p>
                    <div className="text-edit-contain">
                        <textarea className="textarea-edit-body"></textarea>
                    </div>
                </div>


                <div className="submit-for-approval-btn-contain">
                    <button className="submit-for-approval-btn round-btn">Submit for Approval</button>
                </div>
            </div>
        )
    }
}

export default ConfigureNewFundingPortal
