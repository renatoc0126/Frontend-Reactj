import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import fundingData from '../../../data/fundingData.json'
import PendingIcon from '@material-ui/icons/ReportProblemOutlined'
import ActiveIcon from '@material-ui/icons/CheckCircleOutlineOutlined'
import Select from "react-select";
import '../../../css/dashboard/funding.css'

const options = [
    { value: "edit", label: "Edit" },
    { value: "delete", label: "Delete" },
    { value: "statistics", label: "Statistics" },
    { value: "asset detail", label: "Asset detail" },
  ];

export class index extends Component {
    constructor(props){
        super(props);
        this.state = {
            currentPage: 0,
            tableDatas: [],
            showDatas: [],
        }
    }
    componentDidMount(){
        this.props.selectLeftSidebar('fundingState');
        this.setState({tableDatas: fundingData});
        var temp = [];
        if(fundingData.length>10)
            temp = fundingData.slice(0, 10);
        else
            temp = fundingData.slice(0, fundingData.length);
        this.setState({showDatas: temp});
    }


    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    render() {
        return (
            <div className="funding-portal-container animation-effect">
                <div className="funding-title-btn-main">
                    <p className="dashboard-sub-title dark-blue">Funding Portal Management</p>
                    <Link to={'/dashboard/configure-new-funding-portal'} className="link-style">
                    <button className="configure-new-funding">Configure New Funding Portal</button>
                    </Link>
                </div>
                <div>
                    <table className="funding-table">
                        <thead>
                            <tr style={{color: "#D74B4B"}}>
                                <th>Name</th>
                                <th>Created Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.showDatas.map((data, i) => 
                            <tr key={i}>
                                <td>{data.name}</td>
                                <td>{data.created_date}</td>
                                <td>
                                    {(data.status === '1') ? 
                                        <div className="table-td-pending"><PendingIcon className="pending-icon"/> Pending</div>: 
                                        <div className="table-td-active"><ActiveIcon className="acitve-icon"/>Active</div>
                                        }
                                    </td>
                                {/* <td>
                                    <i className="fa fa-file-text-o"></i>
                                    <i className="fa fa-trash"></i>
                                </td> */}
                                <td>
                                    <Select options={options}  defaultValue={{ label: "Edit", value: 0 }}/>
                                </td>
                            </tr>
                            )}
                        </tbody>
                    </table>

                    <div className="table-num-arrow-main">
                        <p>Showing {this.state.currentPage*10 + 1} - {this.state.currentPage*10 + 10} of {this.state.tableDatas.length}</p>
                        <div>
                            <i className="fa fa-long-arrow-left" onClick={()=>this.handlePagePrevious()}></i>
                            <i className="fa fa-long-arrow-right" onClick={()=>this.handlePageNext()}></i>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default index
