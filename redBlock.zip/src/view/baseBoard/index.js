import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import '../../css/baseBoard.css';

class BaseBoard extends Component {
    state = {  }
    render() { 
        return (  
            
            <div className="container baseBoard">
                <div className="base-subBase row">
                    <div className="col-md-4 col-sm-12">
                        <Link to={'/assets-detail'}>
                            <div className="one-block">
                                WEBPAGE
                            </div>
                        </Link>
                    </div>
                </div>
                <div className="base-subBase row">
                    <div className="col-md-4 col-sm-12">
                        <Link to={'/issuer-log-in'}>
                            <div className="one-block">
                                Issure
                            </div>
                        </Link>
                    </div>
                    <div className="col-md-4 col-sm-12">
                        <Link to={'/investor-sign-up'}>
                            <div className="one-block">
                                Investor
                            </div>
                        </Link>
                    </div>
                    <div className="col-md-4 col-sm-12">
                        <Link to={'/admin-dashboard/account'}>
                            <div className="one-block">
                                Admin
                            </div>
                        </Link>
                    </div>
                </div>
            </div>
        );
    }
}
 
export default BaseBoard;