import React, { Component } from 'react'
import TopHeader from '../../components/common/Header/TopHeader';
import ConfiureFundingPortalContent from '../../components/ConfiureFundingPortalPage/ConfiureFundingPortalContent';

export class index extends Component {
    render() {
        return (
            <div>
                <TopHeader />

                <ConfiureFundingPortalContent />

            </div>
        )
    }
}

export default index