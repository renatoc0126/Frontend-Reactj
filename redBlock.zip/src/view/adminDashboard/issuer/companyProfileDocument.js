import React, { Component } from 'react';

// import download_img from '../../../assets/images/square-download.png';
import SpaceBarIcon from '@material-ui/icons/SpaceBar';
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';

class CompanyProfileDocument extends Component {
    render() { 
        return (  
            <div className="row">
                <div className="form-group profile-row col-sm-7 col-xs-12">
                    <label>{this.props.data.doc_name}</label>
                    <div className="admin-pager-funding-portal-container">
                        <img src={"../assets/icons/paperclip-red.png"} className="alert-icon" alt="alert png" />
                        <p className="subtitle-desc mb-0">Incorporate_doc_2020.PDF</p>
                    </div>
                    {/* <div className="input-group">                                        
                        <div className="input-group-prepend ">
                            <span className="input-group-text paper-pre"><i className="fa fa-paperclip paper-icon" aria-hidden="true"></i></span>
                        </div>                               
                        <input type="text" className="form-control prepend-input"
                        name="#"
                        placeholder={this.props.data.file_name} />
                    </div> */}
                </div>

                
                                       
                <div className="download-button col-sm-5 col-xs-12">
                    <div>
                        <button className="btn">Download 
                            <div className="icons" >
                                <div><ArrowDownwardIcon/></div>
                                <div><SpaceBarIcon /></div>
                            </div> 
                        </button>
                    </div>
                    
                </div>
            </div>
       );
    }
}
 
export default CompanyProfileDocument;