import React, { Component } from 'react'
import IconButton from '@material-ui/core/IconButton';
import Select from "react-select";

import adminIssuerData from '../../../data/adminInvestmentProfileData.json';

import '../../../css/adminDashboard/issuer.css';

const options1 = [
    { value: "approve", label: "Approve" },
    { value: "decline", label: "Decline" },    
  ];
const options2 = [
    { value: "approve", label: "Approve" },
    { value: "decline", label: "Decline" },    
  ];

export class index extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }

    componentDidMount(){
        this.props.selectLeftSidebar('investorState');

        this.setState({tableDatas: adminIssuerData});
        this.setState({originData: adminIssuerData});
        var temp = [];
        if(adminIssuerData.length>10)
            temp = adminIssuerData.slice(0, 10);
        else
            temp = adminIssuerData.slice(0, adminIssuerData.length);
        this.setState({showDatas: temp});
    }

    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }

    render() {
        return (
            <div className="admin-issuer-container main-dashboard-container animation-effect investor-assets-container">
                <div className="flex-align-justify investor-search-main-body">
                    <p className="in-dashboard-sub-title dark-blue mb-0">Investment Profile</p>
                    <div className="investor-search-wrapper">
                        <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                        <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                            <i className="fa fa-search"></i>
                        </IconButton>
                    </div>
                </div>
                <div className="main-asset-table-contain">
                    <div className="investor-profile-body">
                        <table className="main-asset-table investor-profile-content">
                            <thead>
                                <tr>
                                    <th>Offering name</th>
                                    <th>Issuer</th>                                
                                    <th>Round</th>
                                    <th>Business sector</th>
                                    <th>Exemption</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Price per unit</th>
                                    <th>Created date</th>
                                    <th>Closed date</th>
                                    <th>Documents</th>
                                    <th>Transections</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>                            
                            {this.state.showDatas.map((data, i) => 
                                <tr key={i}>
                                    <td> {data.offering_name}</td>
                                    <td> {data.issuer}</td>
                                    <td> {data.round}</td>
                                    <td> {data.businee_sector}</td>
                                    <td> {data.exemption}</td>
                                    <td> {data.type}</td>
                                    <td> {data.amount}</td>
                                    <td> {data.price_per_unit}</td>
                                    <td> {data.created_date}</td>
                                    <td> {data.closed_date}</td>
                                    <td><i className="fa fa-file-text-o" aria-hidden="true"></i></td>                                    
                                    <td className="special-width">
                                        <Select options={options1}  defaultValue={{ label: "Approve", value: 0 }}/>
                                    </td>
                                    <td className="special-width">
                                        <Select options={options2}  defaultValue={{ label: "Approve", value: 0 }}/>
                                    </td>                    
                                </tr>
                                )}
                            </tbody>
                        </table>
                    </div>                    
                </div>
            </div>
        )
    }
}

export default index
