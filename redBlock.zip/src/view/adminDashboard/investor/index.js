import React, { Component } from 'react'
import IconButton from '@material-ui/core/IconButton';
import Select from "react-select";

import adminIssuerData from '../../../data/adminInvestorData.json';

import '../../../css/adminDashboard/issuer.css';

const options1 = [
    { value: "view", label: "View" },
    { value: "pass", label: "Pass" },    
  ];
const options2 = [
    { value: "view", label: "View" },
    { value: "pass", label: "Pass" },    
  ];

export class index extends Component {
    constructor(props){
        super(props);
        this.onChangeSearch = this.onChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.state = {
            currentPage: 0,
            originData: [],
            tableDatas: [],
            showDatas: [],
            search_value: "",
        }
    }

    componentDidMount(){
        this.props.selectLeftSidebar('investorState');

        this.setState({tableDatas: adminIssuerData});
        this.setState({originData: adminIssuerData});
        var temp = [];
        if(adminIssuerData.length>10)
            temp = adminIssuerData.slice(0, 10);
        else
            temp = adminIssuerData.slice(0, adminIssuerData.length);
        this.setState({showDatas: temp});
    }

    handlePagePrevious = () => {
        if(this.state.currentPage>0){
            this.setState({currentPage: this.state.currentPage - 1}, () => {
                var temp = [];
                if(this.state.tableDatas.length<10){
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                }
                else{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                }
                
            });
        }
    }

    handlePageNext = () => {
        if((this.state.currentPage*10 + 10) < this.state.tableDatas.length){
            var temp = [];
            if((this.state.currentPage*10 + 20) < this.state.tableDatas.length)
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.currentPage*10 + 10);
                    this.setState({showDatas: temp});
                });
            else
                this.setState({currentPage: this.state.currentPage + 1}, ()=>{
                    console.log(this.state.tableDatas.length);
                    temp = this.state.tableDatas.slice(this.state.currentPage*10, this.state.tableDatas.length);
                    this.setState({showDatas: temp});
                });
           
        }
    }

    handleSearch(){
        const {search_value} = this.state;
        var value = search_value.toLocaleLowerCase();
        var temp = this.state.originData.filter((object) => 
            {
                for (var key in object){
                    if(object[key].toLocaleLowerCase().indexOf(value)>-1)
                    return true;
                }
                return null;
            }
        );
        this.setState({tableDatas: temp}, ()=>{
            var tempdata = [];
            if(this.state.tableDatas.length<10){
                tempdata = this.state.tableDatas.slice(0, this.state.tableDatas.length);
                this.setState({showDatas: tempdata});
            }
            else{
                tempdata = this.state.tableDatas.slice(0, 10);
                this.setState({showDatas: tempdata});
            }
        });
    }

    onChangeSearch(e){
        this.setState({
            search_value: e.target.value
        })
    }

    handleKeyPress(e){
        if(e.key === "Enter")
            this.handleSearch();
    }

    handleRedblock = () => {
        const { history } = this.props;
        history.push({ pathname: '/admin-dashboard/investor-redblock'});
        console.log(history);
    }


    render() {
        return (
            <div className="admin-issuer-container main-dashboard-container animation-effect investor-assets-container">
                <div className="flex-align-justify investor-search-main-body">
                    <p className="in-dashboard-sub-title dark-blue mb-0">Investor</p>
                    <div className="investor-search-wrapper">
                        <input type="text" value={this.state.search_value} onChange={this.onChangeSearch} onKeyPress={this.handleKeyPress} placeholder="Search here"></input>
                        <IconButton className="search-icon-btn" onClick={this.handleSearch}>
                            <i className="fa fa-search"></i>
                        </IconButton>
                    </div>
                </div>
                <div className="main-asset-table-contain">
                    <table className="main-asset-table admin-investor-content-table">
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>                                
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Password</th>
                                <th>Country</th>
                                <th>Wallet</th>
                                <th>KYC profile</th>
                                <th>Accreditation profile</th>
                                <th>Investment Profile</th>
                            </tr>
                        </thead>
                        <tbody>                            
                        {this.state.showDatas.map((data, i) => 
                            <tr key={i} style={{cursor: "pointer"}}>
                                <td onClick={() => this.handleRedblock()}> {data.first_name}</td>
                                <td onClick={() => this.handleRedblock()}> {data.last_name}</td>
                                <td onClick={() => this.handleRedblock()}> {data.email}</td>
                                <td onClick={() => this.handleRedblock()}> {data.phone}</td>
                                <td onClick={() => this.handleRedblock()}> {data.password}</td>
                                <td onClick={() => this.handleRedblock()}> {data.country}</td>
                                <td onClick={() => this.handleRedblock()}> {data.wallet}</td>
                                <td>
                                    <Select options={options1}  defaultValue={{ label: "View", value: 0 }}/>
                                </td>
                                <td>
                                    <Select options={options2}  defaultValue={{ label: "View", value: 0 }}/>
                                </td>
                                <td onClick={() => this.handleRedblock()}> {data.invest_profile}</td>                                
                            </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default index
