import Account from './view/adminDashboard/account';
import Issuer from './view/adminDashboard/issuer';
import IssuerRedblock from './view/adminDashboard/issuer/redblock';
import Investor from './view/adminDashboard/investor';
import InvestorRedblock from './view/adminDashboard/investor/investmentProfile';





const routes = [
  { path: '/admin-dashboard/account', name: 'adminAccount', component: Account },
  { path: '/admin-dashboard/issuer', name: 'adminIssuer', component: Issuer },
  { path: '/admin-dashboard/issuer-redblock', name: 'adminIssuer', component: IssuerRedblock },
  { path: '/admin-dashboard/investor', name: 'adminInvestor', component: Investor },
  { path: '/admin-dashboard/investor-redblock', name: 'adminInvestor', component: InvestorRedblock },


];

export default routes;
