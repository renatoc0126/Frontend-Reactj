import React, { Component } from 'react'
import Select from "react-select";
import IconButton from '@material-ui/core/IconButton';
import '../../css/configureFundingPortal.css';
const BusinessSector = [
    { value: "BusinessSector1", label: "BusinessSector 1" },
    { value: "BusinessSector2", label: "BusinessSector 2" },
    { value: "BusinessSector3", label: "BusinessSector 3" },
  ];
const country = [
    { value: "China", label: "China" },
    { value: "UniteState", label: "UniteState" },
    { value: "Serbia", label: "serbia" },
];

const amountRaised =[
    { value: "option1", label: "option 1" },
    { value: "option2", label: "option 2" },
    { value: "option3", label: "option 3" },
];
const percentage = [
    { value: "option1", label: "10%" },
    { value: "option2", label: "20%" },
    { value: "option3", label: "30%" },
];
export class ConfigureFundingPortal extends Component {

    render() {
        return (
            <div className="user-configure-funding-portal-container">
                <div className="red-rectangle-container"></div>
                <div className="container">
                    <div className="confiure-new-funding-portal-container animation-effect">
                        <div className="asset-info-container">
                            <div className="asset-input-group">
                                <p className="asset-title">Asset info</p>
                                <div className="form-group dashboard-form-group">
                                    <label>Asset Name</label>
                                    <input type="text" className="form-control"></input>
                                </div>
                                <div className="form-group dashboard-form-group">
                                    <label>Target Raise</label>
                                    <input type="text" className="form-control"></input>
                                </div>
                                <div className="form-group dashboard-form-group">
                                    <label>Business Sector</label>
                                    <Select options={BusinessSector} />
                                </div> 
                                <div className="form-group dashboard-form-group">
                                    <label>Asset Website</label>
                                    <input type="text" className="form-control"></input>
                                </div>
                                <div className="form-group dashboard-form-group">
                                    <label>Country</label>
                                    <Select options={country} />
                                </div> 
                                <div className="form-group dashboard-form-group">
                                    <label>Social Media Link</label>
                                    <input type="text" className="form-control"></input>
                                </div>

                                <button className="add-more-link-btn">Add more Link</button>
                                
                            </div>
                            <div className="asset-input-upload-edit">
                                <div className="upload-edit-contain">
                                    <div className="http-inputbox-container">
                                        <input type="text" placeholder="http://" />
                                        <p>Upload YouTube Channel Link</p>
                                    </div>
                                    <div>
                                        <IconButton component="label" className="upload-icon-btn">
                                            <i className="fa fa-cloud-upload"></i>
                                            <input
                                                type="file"
                                                name="media"
                                                accept="audio/*,video/*,image/*"
                                                style={{ display: "none" }}
                                            />
                                        </IconButton>

                                        <p>Upload Media</p>
                                    </div>
                                    <div>
                                        
                                        <button>
                                            <i className="fa fa-pencil-square-o"></i>
                                            Edit
                                        </button>
                                        <p>Drag your media files here or browse</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="funding-high-ligt">
                            <p className="asset-title">Highlight</p>
                            <p className="small-sub-title">Why Invest Us?</p>
                            <div className="text-edit-contain highlight-invest-conatiner">
                                <p>1.</p>
                                <textarea className="textarea-edit-body"></textarea>
                            </div>
                            <div className="text-edit-contain highlight-invest-conatiner">
                                <p>2.</p>
                                <textarea className="textarea-edit-body"></textarea>
                            </div>
                            <div className="text-edit-contain highlight-invest-conatiner">
                                <p>3.</p>
                                <textarea className="textarea-edit-body"></textarea>
                            </div>
                            <button className="add-more-link-btn">Add more</button>

                        </div>

                        <div className="funding-high-ligt">
                            <p className="asset-title">Overview</p>
                            <div className="text-edit-contain">
                                <textarea className="textarea-edit-body"></textarea>
                            </div>
                        </div>

                        <div className="funding-high-ligt">
                            <p className="asset-title">Description</p>
                            <div className="text-edit-contain">
                                <textarea className="textarea-edit-body"></textarea>
                            </div>
                        </div>

                        <div className="funding-high-ligt pitch-dech-upload-main">
                            <p className="asset-title">Pitch Deck (PDF)</p>
                            <div className="pitch-dech-upload-contain">
                                <IconButton component="label" className="upload-icon-btn">
                                    <i className="fa fa-cloud-upload"></i>
                                    <input
                                        type="file"
                                        name="pdf"
                                        accept=".doc, .docx,.ppt, .pptx,.txt,.pdf"
                                        style={{ display: "none" }}
                                    />
                                </IconButton>
                                <p>Upload PDF file</p>
                            </div>
                        </div>

                        <div className="funding-high-ligt">
                            <p className="asset-title">Team Member</p>
                            <div className="team-member-container">
                                <div>
                                    <IconButton component="label" className="upload-icon-btn">
                                        <i className="fa fa-cloud-upload"></i>
                                        <input
                                            type="file"
                                            name="media"
                                            accept="audio/*,video/*,image/*"
                                            style={{ display: "none" }}
                                        />
                                    </IconButton>
                                    <p>Upload photo</p>
                                </div>
                                <div>
                                    <div className="form-group dashboard-form-group">
                                        <label>Asset Name</label>
                                        <input type="text" className="form-control"></input>
                                    </div>
                                    <div className="form-group dashboard-form-group">
                                        <label>Position</label>
                                        <input type="text" className="form-control"></input>
                                    </div>
                                    <div className="form-group dashboard-form-group">
                                        <label>Description</label>
                                        <input type="text" className="form-control"></input>
                                    </div>
                                </div>
                            </div>
                            <button className="add-more-link-btn mt-4">Add more</button>
                        </div>

                        
                        <div className="funding-high-ligt use-of-procced-main-container">
                            <p className="asset-title">Use of Procced</p>
                            <div className="use-of-procced-select-container">
                                <div className="form-group dashboard-form-group">
                                    <label>If minimum amount raised</label>
                                    <Select options={amountRaised} />
                                </div>
                                <div className="form-group dashboard-form-group">
                                    <label>Percentage</label>
                                    <Select options={percentage} />
                                </div> 
                            </div>
                            <button className="add-more-link-btn mb-4" style={{position: "relative"}}>Add more</button>

                            <div className="use-of-procced-select-container">
                                <div className="form-group dashboard-form-group">
                                    <label>If maximum amount raised</label>
                                    <Select options={amountRaised} />
                                </div>
                                <div className="form-group dashboard-form-group">
                                    <label>Percentage</label>
                                    <Select options={percentage} />
                                </div> 
                            </div>
                            <button className="add-more-link-btn">Add more</button>
                        </div>

                        <div className="funding-high-ligt">
                            <p className="asset-title">Risk Factors & Disclosure</p>
                            <div className="text-edit-contain">
                                <textarea className="textarea-edit-body"></textarea>
                            </div>
                        </div>


                        <div className="submit-for-approval-btn-contain">
                            <button className="submit-for-approval-btn round-btn">Submit for Approval</button>
                            <button className="save-as-draft">Save as Draft</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ConfigureFundingPortal
