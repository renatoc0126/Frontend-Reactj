import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import '../../css/dashboard/layout.css'
import '../../css/dashboard/leftSidebar.css'



export class LeftSideBar extends Component {
    constructor(props){
        super(props);
        this.state = {
            accountState: false,
            fundingState: false,
            kycState: false,
            dashboardState: false,
            bankingState: false,
            supportState: false,
        }
    }

    handleLinkActive = (txt) => {
        this.setState({accountState: false, fundingState: false, kycState:false, dashboardState:false, bankingState:false, supportState:false});
        this.setState({[txt]: true});
    }

    selectLeftSidebar = (txt) => {
        this.setState({accountState: false, fundingState: false, kycState:false, dashboardState:false, bankingState:false, supportState:false});
        this.setState({[txt]: true});
    }

    render() {
        const {accountState, fundingState, kycState, dashboardState, bankingState, supportState } = this.state;
        return (
            <div className="dashboard-left-sidebar" id="leftSidebar">
                <div className={(accountState) ? "left-sidebar-item left-sidebar-active":"left-sidebar-item"} >
                    <Link to={'/dashboard/account'} className="nav-item-link link-style" onClick={() => this.handleLinkActive("accountState")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="29" viewBox="0 0 26 29">
                            <g transform="translate(-3 -2)">
                            <path className={(accountState) ? "left-sidebar-active user-svg": "user-svg"} d="M28,23.878V20.918A5.96,5.96,0,0,0,22,15H10a5.96,5.96,0,0,0-6,5.918v2.959" transform="translate(0 6.122)"/>
                            <circle className={(accountState) ? "left-sidebar-active user-svg": "user-svg"} cx="5.808" cy="5.808" r="5.808" transform="translate(10.424 3)"/>
                            </g>
                        </svg>
                        <span className={(accountState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Account</span>
                    </Link>
                </div>

                <div className={(fundingState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/dashboard/funding-portal'} className="nav-item-link link-style" onClick={()=>this.handleLinkActive("fundingState")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
                            <g transform="translate(-2 -2)">
                                <rect className={(fundingState) ? "left-sidebar-active fund-portial-svg": "fund-portial-svg"} width="24" height="24" rx="2" transform="translate(3 3)"/>
                                <path className={(fundingState) ? "left-sidebar-active fund-portial-svg": "fund-portial-svg"} d="M7,7h4V19H7Z" transform="translate(1.333 1.333)"/>
                                <path className={(fundingState) ? "left-sidebar-active fund-portial-svg": "fund-portial-svg"} d="M14,7h4v6.667H14Z" transform="translate(3.667 1.333)"/>
                            </g>
                        </svg>
                        <span className={(fundingState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Funding Portial</span>
                    </Link>
                </div>

                <div className={(kycState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/dashboard/kyc'} className="nav-item-link link-style" onClick={()=>this.handleLinkActive("kycState")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="26.414" height="26.414" viewBox="0 0 26.414 26.414">
                            <g transform="translate(-2 -2)">
                            <circle className={(kycState) ? "left-sidebar-active zoom-out-svg":"zoom-out-svg"} cx="10.5" cy="10.5" r="10.5" transform="translate(3 3)"/>
                            <path className={(kycState) ? "left-sidebar-active zoom-out-svg":"zoom-out-svg"}  d="M22.45,22.45l-5.8-5.8" transform="translate(4.55 4.55)"/></g>
                        </svg>
                        <span className={(kycState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>KYC/AML</span>
                    </Link>
                </div>

                <div className={(dashboardState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/dashboard/assets'} className="nav-item-link link-style"  onClick={()=>this.handleLinkActive("dashboardState")}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="26.013" height="28.809" viewBox="0 0 26.013 28.809">
                                <g transform="translate(-1.994 -0.964)">
                                <path className={(dashboardState) ? "left-sidebar-active package-svg": "package-svg"} d="M19.5,11.13,7.5,4.21" transform="translate(1.5 0.736)"/>
                                <path className={(dashboardState) ? "left-sidebar-active package-svg": "package-svg"} d="M27,20.666V10a2.667,2.667,0,0,0-1.333-2.307L16.333,2.359a2.667,2.667,0,0,0-2.667,0L4.333,7.693A2.667,2.667,0,0,0,3,10V20.666a2.667,2.667,0,0,0,1.333,2.307l9.333,5.333a2.667,2.667,0,0,0,2.667,0l9.333-5.333A2.667,2.667,0,0,0,27,20.666Z"/>
                                <path className={(dashboardState) ? "left-sidebar-active package-svg": "package-svg"} d="M3.27,6.96l11.64,6.733L26.55,6.96" transform="translate(0.09 1.653)"/>
                                <path className={(dashboardState) ? "left-sidebar-active package-svg": "package-svg"} d="M12,25.44V12" transform="translate(3 3.333)"/>
                                </g>
                            </svg>
                        <span className={(dashboardState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Dashboard</span>
                    </Link>
                </div>

                <div className={(bankingState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/dashboard/banking'} className="nav-item-link link-style"  onClick={()=>this.handleLinkActive("bankingState")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="23.6" viewBox="0 0 26 23.6">
                            <g transform="translate(-1 -2)">
                                <rect className={(bankingState) ? "left-sidebar-active briefcase-svg": "briefcase-svg"} width="24" height="17" rx="2" transform="translate(2 7.6)"/>
                                <path className={(bankingState) ? "left-sidebar-active briefcase-svg": "briefcase-svg"} d="M17.6,24.6V5.4A2.4,2.4,0,0,0,15.2,3H10.4A2.4,2.4,0,0,0,8,5.4V24.6" transform="translate(1.2 0)"/>
                            </g>
                        </svg>
                        <span className={(bankingState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Banking</span>
                    </Link>
                </div>

                <div className={(supportState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/dashboard/support'} className="nav-item-link link-style"  onClick={()=>this.handleLinkActive("supportState")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="28.667" viewBox="0 0 26 28.667">
                            <g transform="translate(-2 -1)">
                                <path className={(supportState) ? "left-sidebar-active twitch-svg": "twitch-svg"} d="M27,2H3V23.333H9.667v5.333L15,23.333h6.667L27,18ZM13.667,14V8.667M20.333,14V8.667"/>
                            </g>
                        </svg>
                        <span className={(supportState) ?"left-sidebar-title-active left-sidebar-title" : "left-sidebar-title"}>Support</span>
                    </Link>
                </div>

            </div>
        )
    }
}

export default LeftSideBar
