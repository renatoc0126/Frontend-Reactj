import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import MenuIcon from '@material-ui/icons/Menu'
import HomeOutlinedIcon from '@material-ui/icons/HomeOutlined'
import PowerSettingsNewOutlinedIcon from '@material-ui/icons/PowerSettingsNewOutlined'

export class Header extends Component {
    constructor(props){
        super(props);
        this.state = {
            leftSidebarState: true,
        }
    }

    componentDidMount(){
        var dashboardHeader = document.getElementById('dashboardHeader');
        if (window.innerWidth <= 992) {
            dashboardHeader.style.width = "100%";
        }
        else{
            document.getElementById("dashboardMask").style.display = "none";
        }
    }



    UNSAFE_componentWillMount = () => {

        if (window.innerWidth <= 992) {
            this.setState({ leftSidebarState: false });

        }
        else{
            this.setState({ leftSidebarState: true });
        }
    }

    handleLeftSidebar = () =>{
        var leftsidebar = document.getElementById("leftSidebar");
        var dashboardMain = document.getElementById('dashboardMain');
        var dashboardHeader = document.getElementById('dashboardHeader');
        this.setState({leftSidebarState: !this.state.leftSidebarState}, () => {
            if(!this.state.leftSidebarState){
                leftsidebar.style.marginLeft = "-300px";
                dashboardMain.style.marginLeft = "0px";
                dashboardHeader.style.width = "100%";
                if (window.innerWidth <= 992) {
                    document.getElementById("dashboardMask").style.display = "none";
                }
                
            }
            else{
                leftsidebar.style.marginLeft = "0px";
                if (window.innerWidth > 992) {
                    dashboardMain.style.marginLeft = "300px";
                    dashboardHeader.style.width = "calc(100% - 300px)";
                }
                if (window.innerWidth <= 992) {
                    document.getElementById("dashboardMask").style.display = "block";
                }
            }
        })
    }

    closeLeftSidebar = () =>{
        var leftsidebar = document.getElementById("leftSidebar");
        var dashboardMain = document.getElementById('dashboardMain');
        if (window.innerWidth <= 992) {
            this.setState({leftSidebarState: !this.state.leftSidebarState});
            leftsidebar.style.marginLeft = "-300px";
            dashboardMain.style.marginLeft = "0px";
            if (window.innerWidth <= 992) {
                document.getElementById("dashboardMask").style.display = "none";
            }
            document.getElementById("dashboardMask").style.display = "none";
        }
    }
    render() {
        return (
            <div className="dashboard-header" id="dashboardHeader">
                <MenuIcon className="dashboard-menu-icon" onClick={()=>this.handleLeftSidebar()}/>
                
                <div className="d-flex align-items-center">
                    <div className="admin-user-pop-menu-container">
                        <div>
                            <span>John</span>
                            <ExpandMoreIcon className="expand-more-icon" />
                        </div>
                        <div className="admin-user-pop-menu-body">
                            <div>
                                <HomeOutlinedIcon className="home-icon"/>
                                <Link to={'/homepage'} className="pop-menu-link-style">Home</Link>
                            </div>
                            <div>
                                <img src={"../../assets/icons/package.png"} className="dashboard-image" alt="dashboard png"/>
                                <Link to={'/'} className="pop-menu-link-style">Dashboard</Link>
                            </div>
                            <div>
                                <PowerSettingsNewOutlinedIcon className="logout-icon"/>
                                <Link to={'/homepage'} className="pop-menu-link-style">Logout</Link>
                            </div>
                        </div>
                    </div>
                    <div>
                        <img src={'../../assets/images/avatars/6.jpg'} className="img-avatar" alt="avator 6"/>
                    </div>
                </div>
            </div>
        )
    }
}

export default Header
