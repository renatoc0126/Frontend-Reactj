import React, { Component } from 'react'
import HorizontalBar from './HorizontalBar'
export class Product extends Component {

    render() {
        const { data } = this.props;
        return (
            <div className="product-one">
                <div className="product-one-content">
                    <div style={{background: `url(${data.url})`}} className="product-image-div"></div>
                    <div className="product-description">
                        <h4 style={{color: "#475F77", fontWeight: "bold"}}>{data.title}</h4>
                        <p style={{color: "#5E5E5E"}}>{data.description}</p>
                        {/* <p className="product-store">{data.store}</p> */}
                        <HorizontalBar percent={data.percent}/>
                        <div className="product-price-body">
                            <div className="product-total-raise">
                                <p style={{color:"#D74B4B"}}>Total Raise</p>
                                <h5 style={{color:"#5E5E5E"}}>${data.total_raise}</h5>
                            </div>
                            <div className="product-min-invest">
                                <p style={{color:"#D74B4B"}}>Min Invest</p>
                                <h5 style={{color:"#5E5E5E"}}>${data.min_invest}</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Product
