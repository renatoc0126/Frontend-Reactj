import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import '../../css/dashboard/layout.css'
import '../../css/dashboard/leftSidebar.css'



export class LeftSideBar extends Component {
    constructor(props){
        super(props);
        this.state = {
            accountState: false,
            issuerState: false,
            investorState: false,
            transferState: false,

        }
    }

    handleLinkActive = (txt) => {
        this.setState({accountState: false, issuerState: false, investorState:false, transferState:false});
        this.setState({[txt]: true});
    }

    selectLeftSidebar = (txt) => {
        this.setState({accountState: false, issuerState: false, investorState:false, transferState:false});
        this.setState({[txt]: true});
    }

    render() {
        const {accountState, issuerState, investorState, transferState} = this.state;
        return (
            <div className="dashboard-left-sidebar" id="leftSidebar">
                <div className={(accountState) ? "left-sidebar-item left-sidebar-active":"left-sidebar-item"} >
                    <Link to={'/admin-dashboard/account'} className="nav-item-link link-style" onClick={() => this.handleLinkActive("accountState")}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="29" viewBox="0 0 26 29">
                            <g transform="translate(-3 -2)">
                            <path className={(accountState) ? "left-sidebar-active user-svg": "user-svg"} d="M28,23.878V20.918A5.96,5.96,0,0,0,22,15H10a5.96,5.96,0,0,0-6,5.918v2.959" transform="translate(0 6.122)"/>
                            <circle className={(accountState) ? "left-sidebar-active user-svg": "user-svg"} cx="5.808" cy="5.808" r="5.808" transform="translate(10.424 3)"/>
                            </g>
                        </svg>
                        <span className={(accountState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Account</span>
                    </Link>
                </div>

                <div className={(issuerState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/admin-dashboard/issuer'} className="nav-item-link link-style" onClick={()=>this.handleLinkActive("issuerState")}>


                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24.001" viewBox="0 0 24 24.001">

                            <g transform="translate(-0.007)">
                            <g transform="translate(3.194 21.188)">
                            <path className={(issuerState) ? "left-sidebar-active issuer-svg":"issuer-svg"} d="M68.8,452.138a.468.468,0,1,0,.137.331A.472.472,0,0,0,68.8,452.138Z" transform="translate(-68.003 -452.001)"/>
                            </g>
                            <g transform="translate(21.216 8.438)">
                            <path className={(issuerState) ? "left-sidebar-active issuer-svg":"issuer-svg"} d="M453.254,180.145a.467.467,0,1,0,.138.331A.471.471,0,0,0,453.254,180.145Z" transform="translate(-452.454 -180.008)"/>
                            </g>
                            <g transform="translate(0.007)">
                            <g transform="translate(0)">
                            <path className={(issuerState) ? "left-sidebar-active issuer-svg":"issuer-svg"} d="M23.87.137A.469.469,0,0,0,23.538,0H12.007a.469.469,0,0,0-.469.469V1.81L7.095,3a.469.469,0,0,0-.331.574l2.3,8.594L7.074,14.161a1.406,1.406,0,0,0-1.161-.614h-4.5A1.408,1.408,0,0,0,.007,14.954v7.641A1.408,1.408,0,0,0,1.413,24h4.5a1.409,1.409,0,0,0,1.365-1.068l.557.486A2.362,2.362,0,0,0,9.388,24h14.15a.469.469,0,0,0,.469-.469V.469A.469.469,0,0,0,23.87.137ZM6.382,22.594a.469.469,0,0,1-.469.469h-4.5a.469.469,0,0,1-.469-.469V14.954a.469.469,0,0,1,.469-.469H3.194v5.4a.469.469,0,1,0,.938,0v-5.4H5.913a.469.469,0,0,1,.469.469v7.641ZM7.79,3.785l3.748-1V4.517l-.314.084a.469.469,0,0,0-.331.574A1.264,1.264,0,0,1,10,6.722a.469.469,0,0,0-.331.575L11.5,14.063h-.941l-.485-1.9A.468.468,0,0,0,9.992,12Zm3.748,2.882v3.955l-.855-3.166A2.2,2.2,0,0,0,11.538,6.667Zm6.734,16.4H9.388a1.424,1.424,0,0,1-.936-.351l-1.132-.987V15.242L9.366,13.2l.371,1.452a.469.469,0,0,0,.454.353h9.216a.656.656,0,0,1,0,1.313H14.685a.469.469,0,0,0,0,.938h6.19a.656.656,0,1,1,0,1.313h-6.19a.469.469,0,0,0,0,.938h5.187a.656.656,0,0,1,0,1.313H14.685a.469.469,0,0,0,0,.938h3.588a.656.656,0,1,1,0,1.312Zm4.8,0H19.724a1.588,1.588,0,0,0,0-1.313h.147A1.593,1.593,0,0,0,21.3,19.443a1.592,1.592,0,0,0,.858-2.486V11.016a.469.469,0,0,0-.938,0V16.35a1.594,1.594,0,0,0-.342-.037h-.015a1.593,1.593,0,0,0-1.452-2.25h-.754a2.243,2.243,0,1,0-1.763,0H14.329V5.15a2.207,2.207,0,0,0,1.681-1.681h3.526A2.207,2.207,0,0,0,21.216,5.15V6.607a.469.469,0,0,0,.938,0V4.731a.469.469,0,0,0-.469-.469A1.264,1.264,0,0,1,20.423,3a.469.469,0,0,0-.469-.469H15.591A.469.469,0,0,0,15.122,3,1.264,1.264,0,0,1,13.86,4.263a.469.469,0,0,0-.469.469v9.332h-.916V.938H23.069Zm-5.3-9.757A1.306,1.306,0,1,1,19.078,12,1.307,1.307,0,0,1,17.773,13.306Z" transform="translate(-0.007 0)"/>
                            </g>
                            </g>
                            </g>
                        </svg>

                        <span className={(issuerState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Issuer</span>
                    </Link>
                </div>

                <div className={(investorState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/admin-dashboard/investor'} className="nav-item-link link-style" onClick={()=>this.handleLinkActive("investorState")}>


                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                            <g transform="translate(-1 -1)">
                            <path className={(investorState) ? "left-sidebar-active investor-svg":"investor-svg"} d="M9.935,45H9.161v.774a1.161,1.161,0,1,0,0,2.323h.774a.387.387,0,1,1,0,.774H8.774v-.387H8v1.161H9.161v.774h.774v-.774a1.161,1.161,0,0,0,0-2.323H9.161a.387.387,0,0,1,0-.774h1.161v.387H11.1V45.774H9.935Z" transform="translate(-4.29 -26.968)"/>
                            <path className={(investorState) ? "left-sidebar-active investor-svg":"investor-svg"} d="M49.161,20.419h.774v-.774a1.161,1.161,0,0,0,0-2.323h-.774a.387.387,0,1,1,0-.774h1.161v.387H51.1V15.774H49.935V15h-.774v.774a1.161,1.161,0,1,0,0,2.323h.774a.387.387,0,0,1,0,.774H48.774v-.387H48v1.161h1.161Z" transform="translate(-28.806 -8.581)"/>
                            <path className={(investorState) ? "left-sidebar-active investor-svg":"investor-svg"} d="M45.258,19.516A4.258,4.258,0,1,0,41,15.258,4.263,4.263,0,0,0,45.258,19.516Zm0-7.742a3.484,3.484,0,1,1-3.484,3.484A3.488,3.488,0,0,1,45.258,11.774Z" transform="translate(-24.516 -6.129)"/>
                            <path className={(investorState) ? "left-sidebar-active investor-svg":"investor-svg"} d="M20.742,14.935h2.937l-4.872,4.872-1.935-1.935-2.742,2.742-3.466-2.7L9.217,19.184A4.277,4.277,0,0,0,7.7,17.258h7.237V15.515A3.5,3.5,0,0,0,12.7,12.263l-2.86-1.1L9.6,10.206a3.1,3.1,0,0,0,1.359-1.851h.1a1.543,1.543,0,0,0,1.3-2.379,7.923,7.923,0,0,0,.246-1.942v-.6l-.945-.315.758-1.137-.982-.392A8.159,8.159,0,0,0,8.4,1H7.212a4.276,4.276,0,0,0-2.376.719A3.38,3.38,0,0,0,3.614,5.91,1.543,1.543,0,0,0,4.871,8.355h.1a3.1,3.1,0,0,0,1.359,1.85l-.239.957-2.86,1.1A3.5,3.5,0,0,0,1,15.514v1.744H2.817A4.255,4.255,0,0,0,5.258,25H25v-.774H22.677V17.031l1.548-1.548v2.937H25V14.161H20.742Zm-1.161,5.193v4.1H18.032v-4.1l.774.774Zm-2.323-.774v4.872H15.71v-4.1l1.161-1.161Zm-3.065,2.291.742-.742v3.324H13.387V21.017Zm-3.129-2.434,1.548,1.2v3.811H11.065Zm0-11.63V6.032a.774.774,0,1,1,0,1.548Zm-6.194,0a.774.774,0,0,1,0-1.548Zm.1-2.323h-.1A1.535,1.535,0,0,0,4.24,5.4,2.613,2.613,0,0,1,5.265,2.364a3.5,3.5,0,0,1,1.947-.59H8.4a7.391,7.391,0,0,1,2.758.531l.1.038L10.461,3.53l1.378.459v.045A7.159,7.159,0,0,1,11.7,5.4a1.536,1.536,0,0,0-.64-.142h-.1A1.686,1.686,0,0,0,9.356,4.1H6.58A1.686,1.686,0,0,0,4.968,5.258Zm.677,2.323V5.806a.935.935,0,0,1,.934-.935H9.356a.935.935,0,0,1,.934.934V7.581a2.323,2.323,0,1,1-4.645,0Zm2.323,3.1a3.1,3.1,0,0,0,.921-.14l.223.892a1.22,1.22,0,0,1-2.288,0l.223-.891a3.088,3.088,0,0,0,.922.14ZM1.774,16.484v-.97a2.727,2.727,0,0,1,1.737-2.529l2.7-1.038a2,2,0,0,0,3.518,0l2.7,1.038a2.726,2.726,0,0,1,1.737,2.529v.97Zm0,4.258a3.484,3.484,0,1,1,3.484,3.484A3.488,3.488,0,0,1,1.774,20.742Zm7.742,0a4.232,4.232,0,0,0-.068-.733l.842-.737v4.954H7.7A4.254,4.254,0,0,0,9.516,20.742ZM21.9,24.226H20.355V19.354L21.9,17.805Z"/>
                            </g>
                        </svg>
                        <span className={(investorState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Investor</span>
                    </Link>
                </div>

                <div className={(transferState) ? "left-sidebar-active left-sidebar-item": "left-sidebar-item"}>
                    <Link to={'/admin-dashboard/transfer'} className="nav-item-link link-style"  onClick={()=>this.handleLinkActive("transferState")}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M20.5,11a.472.472,0,0,1-.5-.5v-5A1.538,1.538,0,0,0,18.5,4h-8a.472.472,0,0,1-.5-.5.472.472,0,0,1,.5-.5h8A2.476,2.476,0,0,1,21,5.5v5A.472.472,0,0,1,20.5,11Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M20.5,11a.6.6,0,0,1-.4-.1l-2-2a.495.495,0,1,1,.7-.7l1.6,1.6L22,8.2a.495.495,0,0,1,.7.7l-2,2c.1.1-.1.1-.2.1Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M11.5,21h-6A2.476,2.476,0,0,1,3,18.5v-5a.472.472,0,0,1,.5-.5.472.472,0,0,1,.5.5v5A1.538,1.538,0,0,0,5.5,20h6a.5.5,0,0,1,0,1Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M5.5,16a.6.6,0,0,1-.4-.1L3.5,14.3,1.9,15.9a.483.483,0,0,1-.7,0,.483.483,0,0,1,0-.7l2-2a.483.483,0,0,1,.7,0l2,2a.483.483,0,0,1,0,.7A.6.6,0,0,1,5.5,16Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M5,5A2.476,2.476,0,0,1,2.5,2.5a2.5,2.5,0,0,1,5,0A2.476,2.476,0,0,1,5,5ZM5,1A1.538,1.538,0,0,0,3.5,2.5,1.538,1.538,0,0,0,5,4,1.538,1.538,0,0,0,6.5,2.5,1.538,1.538,0,0,0,5,1Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M9.5,10A.472.472,0,0,1,9,9.5v-1A1.538,1.538,0,0,0,7.5,7h-5A1.538,1.538,0,0,0,1,8.5v1a.472.472,0,0,1-.5.5A.472.472,0,0,1,0,9.5v-1A2.476,2.476,0,0,1,2.5,6h5A2.476,2.476,0,0,1,10,8.5v1A.472.472,0,0,1,9.5,10Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M19,19a2.5,2.5,0,1,1,2.5-2.5A2.476,2.476,0,0,1,19,19Zm0-4a1.5,1.5,0,1,0,1.5,1.5A1.538,1.538,0,0,0,19,15Z"/>
                                <path className={(transferState) ? "left-sidebar-active transfer-svg": "transfer-svg"} d="M23.5,24a.472.472,0,0,1-.5-.5v-1A1.538,1.538,0,0,0,21.5,21h-5A1.538,1.538,0,0,0,15,22.5v1a.5.5,0,0,1-1,0v-1A2.476,2.476,0,0,1,16.5,20h5A2.476,2.476,0,0,1,24,22.5v1A.472.472,0,0,1,23.5,24Z"/>
                            </svg>
                        <span className={(transferState) ? "left-sidebar-title-active left-sidebar-title": "left-sidebar-title"}>Transfer</span>
                    </Link>
                </div>

            </div>
        )
    }
}

export default LeftSideBar
