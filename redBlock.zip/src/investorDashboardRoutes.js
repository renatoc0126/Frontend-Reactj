import Account from './view/investorDashboard/account'
import Assets from './view/investorDashboard/assets'
import investorDashboardRedblock from './view/investorDashboard/assets/investorDashboardRedblock'

import Kyc from './view/investorDashboard/kyc'
import IdVerify from './view/investorDashboard/kyc/IdVerify'




const routes = [
  { path: '/investor-dashboard/account', name: 'Account', component: Account },
  { path: '/investor-dashboard/assets', name: 'Assets', component: Assets },
  { path: '/investor-dashboard/redblock', name: 'investorDashboardRedbloack', component: investorDashboardRedblock },

  { path: '/investor-dashboard/kyc', name: 'Kyc', component: Kyc },
  { path: '/investor-dashboard/kyc-id-verify', name: 'IdVerify', component: IdVerify },


];

export default routes;
